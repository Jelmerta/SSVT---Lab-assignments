import Exercise1
import Exercise2
import Exercise3
import Exercise4
import Exercise5
import Exercise6
import Exercise7
import Exercise8

main :: IO ()
main = do
    exercise1
    exercise2
    exercise3
    exercise4
    exercise5
    exercise6
    exercise7
    exercise8
